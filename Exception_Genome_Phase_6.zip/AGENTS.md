Continue the existing OCBC Exception Genome project.

Phases 1, 2, 3, 4 and 5 are complete and working.

DO NOT rebuild the application.

DO NOT remove or weaken any existing safety controls.

DO NOT begin n8n integration.

DO NOT create a FastAPI wrapper yet.

DO NOT connect to real banking systems.

This task is:

PHASE 6

Phase 6 turns the current flagship demonstration into a general exception-resolution platform.

Implement:

1. Multi-incident support
2. Singleton exception handling
3. Multiple simultaneous correlation clusters
4. No-confident-root-cause handling
5. Full Human Review Centre
6. Human-authorised controlled actions
7. Operational Memory
8. Historical similarity matching
9. Prevention Engine
10. Complete Audit Trail
11. Final operational analytics
12. Product hardening and presentation polish

The Phase 6 product message is:

Exception Genome does not assume every exception belongs to one root cause.

It determines whether failures are:

- isolated
- related
- part of multiple simultaneous incidents
- uncertain

Then it chooses the appropriate workflow.

The target architecture is:

EXCEPTIONS

to

CORRELATION

to

one of:

ISOLATED ISSUE

CORRELATED CLUSTER

MULTIPLE CLUSTERS

INSUFFICIENT EVIDENCE

then:

DIAGNOSIS

to

RESOLUTION CONTRACT

to

SAFETY GATE

to

IMPACT SANDBOX

then either:

CONTROLLED AUTONOMOUS EXECUTION

or

HUMAN REVIEW

then:

EXECUTION

to

VERIFICATION

to

RESOLUTION

then:

OPERATIONAL MEMORY

then:

PREVENTION INSIGHT


==================================================
PART 1 - GENERALISE INCIDENT ANALYSIS
==================================================

Remove any remaining assumption that:

many exceptions must equal one cluster.

The correlation system must support:

1. one exception and one isolated root cause

2. many exceptions and one shared root cause

3. many exceptions and multiple unrelated root causes

4. many exceptions where some cluster and others remain isolated

5. insufficient evidence to identify any confident root cause

Do not force an exception into a cluster merely because other exceptions exist.

Do not force all active exceptions into one incident.

Every clustering decision must remain evidence-based.


==================================================
PART 2 - CLUSTER OUTCOMES
==================================================

Create explicit analytical outcomes.

CORRELATED_CLUSTER

Use when multiple exceptions have sufficient evidence of a shared cause.

SINGLETON

Use when one exception has no sufficiently correlated peers.

UNASSIGNED

Use when evidence exists but is insufficient to place the exception confidently.

AMBIGUOUS_CLUSTER

Use when several competing groupings remain plausible.

Each exception must have an assignment status.

Do not silently discard exceptions that do not fit a cluster.


==================================================
PART 3 - CLUSTER CONFIDENCE THRESHOLDS
==================================================

Define documented deterministic thresholds.

Example conceptual ranges:

HIGH_CONFIDENCE_CLUSTER

MODERATE_CONFIDENCE_CLUSTER

LOW_CONFIDENCE

DO_NOT_CLUSTER

Use evidence components already available:

- shared dependencies
- topology
- temporal proximity
- error-family compatibility
- recent changes
- historical similarity

Do not choose thresholds solely to make the demo pass.

Document the scoring logic and thresholds.


==================================================
PART 4 - NEW SCENARIO A - EXISTING FLAGSHIP
==================================================

Preserve:

INC-2026-001

DataHub credential failure.

Expected result:

23 exceptions

1 high-confidence cluster

1 shared root cause

DataHub API

Existing Phase 1-5 flow must continue working unchanged.


==================================================
PART 5 - NEW SCENARIO B - ISOLATED SERVICE FAILURE
==================================================

Create:

INC-2026-002

Title:

Merchant Settlement Local Job Failure

Scenario:

Only Merchant Settlement experiences a local processing failure.

No upstream shared service fails.

No other service develops an exception.

Example:

Merchant Settlement

error code:

MS-JOB-502

error family:

PROCESSING_BLOCKED

cause:

local settlement worker entered invalid runtime state

No recent shared infrastructure change exists.

Expected analysis:

1 exception

0 multi-member clusters

1 SINGLETON

Likely root cause:

Merchant Settlement local processing worker

The UI must clearly state:

NO SHARED ROOT CAUSE DETECTED

This is an isolated operational exception.

Do not display the 23-to-1 story here.


==================================================
PART 6 - ISOLATED RESOLUTION PATH
==================================================

For INC-2026-002, the Root Cause Agent may recommend:

RESTART_SINGLE_SERVICE

The Action Registry currently classifies this as A2 CONDITIONAL.

Do NOT downgrade it to A1.

The workflow should therefore become:

Diagnosis

Resolution Contract

Safety Gate

Impact Sandbox

HUMAN AUTHORITY REQUIRED

Human Review Centre

Reviewer approval

Controlled execution

Verification

Closure

The product must demonstrate that:

not every valid remediation should be autonomous.


==================================================
PART 7 - NEW SCENARIO C - MULTIPLE ROOT CAUSES
==================================================

Create:

INC-2026-003

Title:

Concurrent Operations Incident

This scenario should generate two unrelated operational failures at approximately the same time.

Example root cause A:

Scheduler failure

Affected systems:

several scheduled reports or batch-processing services

Example root cause B:

Event Bus failure

Affected systems:

notification or event-dependent services

The exact services must follow the existing dependency graph logically.

Do not invent dependencies that contradict seed topology.

Generate approximately:

8 to 14 total exceptions

with at least:

2 genuine independent clusters.

Expected result:

CLUSTER 1

root cause:

Scheduler

CLUSTER 2

root cause:

Event Bus

The system must NOT merge them simply because they occurred close together.

This is extremely important.


==================================================
PART 8 - MULTI-CLUSTER ANALYSIS UI
==================================================

The Exception Genome page must support multiple clusters.

Example visual:

12 exceptions detected

Cluster EG-A

7 exceptions

Root Cause Candidate:

Scheduler

Correlation:

high

Cluster EG-B

4 exceptions

Root Cause Candidate:

Event Bus

Correlation:

high

Unassigned:

1 exception

Display clusters separately.

Allow the operator to open each cluster independently.

Each cluster gets:

- its own root-cause analysis
- its own Resolution Contract
- its own Safety Gate
- its own simulation
- its own execution status
- its own verification result

Do not let one cluster's decision authorise actions for another.


==================================================
PART 9 - NEW SCENARIO D - AMBIGUOUS EVIDENCE
==================================================

Create:

INC-2026-004

Title:

Ambiguous Dependency Failure

Generate an operational failure where evidence supports at least two plausible root causes.

Example:

A reporting service fails.

Both:

Reference Data Service

and

Batch Processing Engine

show suspicious indicators.

But evidence is incomplete.

Expected:

Root Cause confidence does NOT exceed the autonomous threshold.

Output:

INSUFFICIENT EVIDENCE

or:

AMBIGUOUS ROOT CAUSE

Result:

HUMAN REVIEW REQUIRED

Do not fabricate certainty.

No automated remediation may occur.


==================================================
PART 10 - HUMAN REVIEW CENTRE
==================================================

Create:

ui/review_centre.py

Add navigation:

Review Centre

This is a complete Phase 6 feature.

Cases appear here when:

- root cause is ambiguous
- evidence is incomplete
- Safety Gate requires review
- action is A2
- action is A3
- simulation is FAIL
- simulation is INCONCLUSIVE
- verification fails
- verification is INCONCLUSIVE
- rollback occurs
- execution is blocked
- unexpected operational drift occurs

Each review case must contain:

review_id

incident_id

cluster_id if applicable

created_at

reason

severity

current_status

diagnosis

evidence

alternative hypotheses

proposed action

contract_id

contract_hash

Safety Gate result

Impact Sandbox result

historical matches

execution result if one exists

verification result if one exists

rollback result if one exists


==================================================
PART 11 - REVIEWER ACTIONS
==================================================

Provide:

APPROVE CONTROLLED ACTION

REJECT ACTION

REQUEST MORE EVIDENCE

ESCALATE

CLOSE AS NO ACTION REQUIRED

Not all buttons should be available in all states.

Use deterministic eligibility rules.

Example:

A2 action with:

valid contract

Safety Gate HUMAN_REVIEW_REQUIRED only because of autonomy class

Impact Sandbox PASS

may allow:

APPROVE CONTROLLED ACTION

A3 action such as:

ROTATE_OR_CREATE_CREDENTIAL

must NOT become autonomously executable merely because a reviewer clicks Approve.

For A3:

allow only:

ESCALATE

or

REJECT

unless the system explicitly models a manually executed external action.

Do not weaken the autonomy boundary.


==================================================
PART 12 - REVIEW DECISION RECORD
==================================================

Persist human decisions.

Required fields:

review_decision_id

review_id

incident_id

contract_id

contract_hash

reviewer_identity

decision

reason

created_at

evidence_snapshot

decision_hash

Use a deterministic hash over:

- review case
- contract
- evidence
- decision
- reason

This is for audit integrity.

Do not call it blockchain.


==================================================
PART 13 - REVIEWER IDENTITY
==================================================

This remains a synthetic demo.

Use selectable synthetic reviewers such as:

Operations Reviewer

Senior Operations Reviewer

Risk Reviewer

Do not implement real authentication.

Persist which synthetic role made the decision.

Clearly label this as simulated reviewer identity.


==================================================
PART 14 - HUMAN AUTHORISED EXECUTION
==================================================

Extend the Execution Engine so A2 actions may execute only when:

- contract is valid
- Safety Gate result is HUMAN_REVIEW_REQUIRED only because human authority is needed
- Impact Sandbox is PASS
- a valid current reviewer approval exists
- approval references the exact contract hash
- no relevant state changed since approval
- action type supports human-authorised controlled execution

For INC-2026-002:

RESTART_SINGLE_SERVICE

Target:

Merchant Settlement

may follow this path.

Do not allow human approval to override unrelated failed safety rules.

Example:

If target mismatch exists:

reviewer approval must NOT turn it into an executable action.

Human authority satisfies authority requirements.

It does not erase technical safety failures.


==================================================
PART 15 - VERIFY ISOLATED RESTART
==================================================

For INC-2026-002:

simulate and execute a controlled synthetic Merchant Settlement restart.

Expected:

Merchant Settlement

FAILED

to

RECOVERING

to

HEALTHY

Verify:

- service health
- relevant synthetic operational output
- no other services changed
- no new failures
- isolated exception resolved

Then close the incident only after verification.


==================================================
PART 16 - OPERATIONAL MEMORY
==================================================

Create:

core/operational_memory.py

Create:

ui/memory_view.py

Operational Memory stores knowledge only from completed cases.

Separate:

VERIFIED SUCCESS

FAILED REMEDIATION

ROLLED BACK

HUMAN-RESOLVED

REJECTED

Do not treat every historical case as a successful precedent.


==================================================
PART 17 - MEMORY RECORD MODEL
==================================================

Create a memory record containing:

memory_id

source_incident_id

source_cluster_id

genome_pattern

normalized_error_families

root_dependency

root_cause

affected_services

affected_domains

change_event_type

evidence_summary

resolution_action

action_parameters_without_secrets

autonomy_path

human_review_required

execution_result

verification_result

rollback_result

final_outcome

created_at

success_count

failure_count

last_seen

pattern_version

Do not store:

real secrets

real credentials

private customer data


==================================================
PART 18 - MEMORY ELIGIBILITY
==================================================

A case may be stored as a VERIFIED SUCCESS pattern only when:

- verification result is VERIFIED
- incident or cluster is closed
- remediation result is known
- evidence snapshot exists
- root cause exists
- action exists

Verification failures must not increase successful-resolution count.

Rolled-back cases remain useful history but are marked:

FAILED REMEDIATION

Human-resolved cases may be stored separately with their reviewer decision.


==================================================
PART 19 - HISTORICAL SIMILARITY
==================================================

Implement deterministic historical similarity.

Do not use random similarity.

Compare fields such as:

- root dependency
- normalized error families
- topology pattern
- recent change type
- affected service set
- affected domain set
- temporal pattern
- authentication context
- Genome signatures

Return:

similarity score

matched evidence

different evidence

historical outcome

previous action

previous verification result

previous success rate


==================================================
PART 20 - MEMORY MUST NOT BYPASS SAFETY
==================================================

This is mandatory.

Even if:

historical similarity = 100 percent

and:

previous success rate = 100 percent

the new case must still go through:

Resolution Contract

Safety Gate

Impact Sandbox

Execution readiness

Verification

Historical success may support diagnosis.

It may not grant authority.


==================================================
PART 21 - REPEAT FLAGSHIP SCENARIO
==================================================

Allow INC-2026-001-style incidents to occur again under new incident IDs.

Example:

INC-2026-005

DataHub Credential Failure recurrence.

Do not reuse the original incident ID.

When analysed:

Operational Memory should identify the previous verified DataHub incident.

Example display:

SIMILAR VERIFIED INCIDENT FOUND

Similarity:

calculated value

Previous occurrences:

1 or more

Previous verified remediation:

ACTIVATE_APPROVED_CREDENTIAL_REFERENCE

Historical verification:

VERIFIED

Previous outcome:

RESOLVED

Then continue through all normal safety controls.


==================================================
PART 22 - PATTERN AGGREGATION
==================================================

When several verified incidents match the same operational pattern:

aggregate them into a pattern record.

Example:

Pattern ID:

PAT-DATAHUB-CREDENTIAL

Occurrences:

4

Verified successful resolutions:

4

Failed resolutions:

0

Human escalations:

0

Last seen:

timestamp

Success rate:

100 percent

Do not create fake historical counts.

Counts must come from actual simulated completed incidents.


==================================================
PART 23 - PREVENTION ENGINE
==================================================

Create:

core/prevention_engine.py

Create prevention recommendations from repeated verified patterns.

The Prevention Engine does NOT execute changes.

It produces recommendations only.

Example:

Repeated pattern:

DataHub credential expiry.

Possible preventive recommendation:

Validate approved replacement reference before expiry and schedule controlled activation ahead of the expiry window.

The prevention recommendation should contain:

prevention_id

pattern_id

reason

evidence

recurrence_count

trend

recommended_control

expected_preventable_condition

confidence

status

Do not claim guaranteed prevention.


==================================================
PART 24 - PREVENTION THRESHOLD
==================================================

Do not create prevention recommendations after one occurrence.

Use a configurable recurrence threshold.

Example:

3 verified occurrences.

Require:

- sufficiently similar pattern
- repeated root cause
- verified historical resolutions
- no contradictory failure pattern

If evidence is insufficient:

do not generate a recommendation.


==================================================
PART 25 - PREVENTION UI
==================================================

On Operational Memory page show:

RECURRING PATTERNS

For a qualified pattern:

Occurrences

Verified successes

Failed remediations

Success rate

Last seen

Trend

Then:

PREVENTIVE RECOMMENDATION

Example:

Observed:

Repeated DataHub credential-expiry incidents.

Recommendation:

Introduce a pre-expiry validation and approved-reference activation control.

Evidence:

3 verified occurrences.

Do not automatically execute the recommendation.


==================================================
PART 26 - COMPLETE AUDIT TRAIL
==================================================

Create:

ui/audit_view.py

The Audit Trail must combine events from all phases into one chronological view.

Include:

- incident detection
- exception generation
- Genome analysis
- clustering
- root-cause analysis
- Resolution Contract
- contract version
- Safety Gate
- Impact Sandbox
- readiness
- human review
- execution
- recovery
- verification
- rollback
- closure
- memory creation
- prevention insight

Do not rely only on Phase 5 execution_steps.

Create a unified audit-query layer.


==================================================
PART 27 - AUDIT FILTERS
==================================================

Allow filtering by:

incident

cluster

actor

event type

result

time range

contract hash

review decision

Show:

timestamp

actor

action

decision

result

source

related artifact

Do not dump raw JSON as the primary interface.

Provide expandable structured details.


==================================================
PART 28 - AUDIT TRACEABILITY
==================================================

A reviewer should be able to start from a resolved incident and trace:

Why did the system think these exceptions were related?

What evidence supported the root cause?

What exact Resolution Contract was used?

Which safety rules passed?

What did the Impact Sandbox predict?

Who authorised the action?

What actually executed?

What recovered?

What did verification observe?

Why was the case closed?

What memory record was created?

Implement navigation links or identifiers between artefacts where practical.


==================================================
PART 29 - OPERATIONS ANALYTICS
==================================================

Add a lightweight analytics section to Command Centre.

Use only actual simulator/database values.

Metrics may include:

ACTIVE EXCEPTIONS

ACTIVE INCIDENTS

RESOLVED INCIDENTS

AUTO-RESOLVED INCIDENTS

HUMAN-REVIEWED INCIDENTS

ROLLBACKS

VERIFICATION FAILURES

MEAN RESOLUTION TIME

MEDIAN RESOLUTION TIME

EXCEPTIONS CORRELATED INTO SHARED INCIDENTS

ROOT CAUSES IDENTIFIED

RECURRING PATTERNS

PREVENTIVE RECOMMENDATIONS

Do not invent business savings.

Do not display fake currency savings.

Do not extrapolate to all OCBC operations.


==================================================
PART 30 - AUTOMATION RATE
==================================================

Calculate:

autonomous resolution rate

human-reviewed resolution rate

unresolved rate

from actual completed simulated incidents.

Clearly distinguish:

incident count

from:

exception count.

Do not claim:

23 exceptions auto-resolved

as:

23 independent incidents auto-resolved.

That would misrepresent the product.


==================================================
PART 31 - ROOT CAUSE COMPRESSION METRIC
==================================================

Add a useful metric:

EXCEPTION COMPRESSION

Example:

23 exceptions

became:

1 root-cause incident

Compression ratio:

23:1

For the multi-cluster scenario:

12 exceptions

became:

2 clusters plus 1 isolated issue

Display the actual calculated result.

This is one of the product's distinctive metrics.


==================================================
PART 32 - GENERALISE COMMAND CENTRE
==================================================

Command Centre must no longer assume only one incident exists.

Show:

active incidents

active clusters

isolated exceptions

unassigned exceptions

human review queue count

resolved incidents

Allow selecting an incident.

The dependency graph may support:

ALL ACTIVE INCIDENTS

or:

SELECTED INCIDENT

Do not mix unrelated cluster colours/statuses in a misleading way.


==================================================
PART 33 - INCIDENT DETAIL NAVIGATION
==================================================

Each incident should have:

Overview

Exceptions

Clusters

Diagnosis

Resolution

Review

Verification

Audit

Memory

Not every section must be a separate page.

Use sensible navigation.

Do not overload one screen.


==================================================
PART 34 - PRESENTATION MODE
==================================================

Add a simple:

DEMO MODE

This does not change underlying logic.

It provides a clean presentation flow.

The demo should let the presenter choose scenarios:

A. Shared Root Cause

B. Isolated Failure

C. Multiple Root Causes

D. Ambiguous Evidence

E. Recurring Pattern

Do not hide safety failures in Demo Mode.

Demo Mode only simplifies navigation and scenario selection.


==================================================
PART 35 - RESET BEHAVIOUR
==================================================

Provide two reset concepts.

RESET CURRENT SCENARIO

Clears active demo incident state but preserves Operational Memory.

FULL DEMO RESET

Clears:

incidents

memory

analytics

review history

prevention patterns

and restores seed baseline.

This distinction is necessary to demonstrate recurring incidents.

Test both.


==================================================
PART 36 - MEMORY-PRESERVING RESET
==================================================

For the recurring-pattern demo:

1. resolve one DataHub incident successfully

2. reset current operational scenario while preserving memory

3. trigger another DataHub-style incident with a new ID

4. observe historical similarity

5. resolve it

6. repeat until prevention threshold is reached

The system must calculate counts from these actual demo runs.


==================================================
PART 37 - ROOT CAUSE AGENT GENERALISATION
==================================================

The deterministic root-cause engine must support the new scenarios.

Do not write:

if incident_id == ...

return expected answer

Use:

- topology
- timing
- change evidence
- error compatibility
- cluster membership
- historical evidence
- contradictions

Scenario definitions may contain synthetic facts.

The root-cause engine must reason from those facts.

Deterministic Demo Mode is still allowed and preferred for reliability.

But output must remain evidence-derived.


==================================================
PART 38 - NO CONFIDENT ROOT CAUSE PATH
==================================================

The system must support:

NO_CONFIDENT_ROOT_CAUSE

Do not always return a root cause.

When confidence is below threshold:

Resolution Contract should not propose an autonomous remediation.

Create:

REVIEW REQUIRED

with:

candidate causes

supporting evidence

missing evidence

recommended evidence collection

This is a major trust feature.


==================================================
PART 39 - EVIDENCE REQUEST
==================================================

Human reviewers may select:

REQUEST MORE EVIDENCE

The demo may simulate evidence arriving.

Example for INC-2026-004:

new diagnostic record arrives.

The system:

- appends evidence
- versions the analysis
- recalculates root-cause confidence
- invalidates any stale contract
- reruns necessary downstream decisions

Do not overwrite previous evidence history.

Version it.


==================================================
PART 40 - FAILURE AND MEMORY INTERACTION
==================================================

A verification-failure case from Phase 5 must appear in history.

Operational Memory should show:

Outcome:

FAILED REMEDIATION

Rollback:

COMPLETED

It must NOT become a positive precedent.

If a future incident resembles it:

show:

Historical warning:

A similar remediation previously failed verification.

This should reduce trust in that historical action.

Do not hide failed history.


==================================================
PART 41 - FINAL PRODUCT TRUST CHAIN
==================================================

For every resolved case, make the trust chain traceable:

DETECTION

CORRELATION

DIAGNOSIS

CONTRACT

SAFETY

SIMULATION

AUTHORITY

EXECUTION

VERIFICATION

CLOSURE

MEMORY

For autonomous A1 case:

AUTHORITY may display:

POLICY CONTROLLED

For human-authorised A2 case:

AUTHORITY:

OPERATIONS REVIEWER APPROVED

For unresolved ambiguous case:

chain stops at:

HUMAN REVIEW


==================================================
PART 42 - FINAL NAVIGATION
==================================================

Target navigation:

Command Centre

Incidents

Exception Genome

Resolution Centre

Review Centre

Operational Memory

Audit Trail

Keep navigation clean.

Do not add unnecessary pages.


==================================================
PART 43 - DATABASE
==================================================

Add required Phase 6 tables.

Suggested:

human_reviews

review_decisions

operational_memory

memory_patterns

pattern_occurrences

prevention_recommendations

Add incident/cluster fields as necessary.

Use safe migrations.

Existing Phase 1-5 database structures must remain compatible.


==================================================
PART 44 - TESTS
==================================================

Preserve all existing tests.

Add comprehensive Phase 6 tests.

At minimum verify:

1. singleton exception remains singleton

2. singleton does not get forced into flagship cluster

3. multi-root scenario creates at least two independent clusters

4. temporal proximity alone does not merge unrelated clusters

5. unrelated root dependencies remain separate

6. unassigned exception remains visible

7. ambiguous evidence produces no confident root cause

8. low-confidence diagnosis cannot create autonomous execution path

9. A2 action requires human review

10. A2 action cannot execute without reviewer approval

11. valid reviewer approval permits eligible A2 controlled execution

12. reviewer approval cannot override target mismatch

13. reviewer approval cannot override prohibited A3 action

14. review decision binds to contract hash

15. changed contract invalidates reviewer approval

16. request-more-evidence versions analysis

17. new evidence invalidates stale downstream artefacts

18. isolated restart affects only selected service

19. isolated verification closes valid case

20. verified successful case creates Operational Memory

21. failed verification does not create positive success memory

22. rollback case is stored as failed remediation history

23. repeated incident receives historical similarity match

24. historical match score is deterministic

25. historical memory does not bypass Safety Gate

26. historical memory does not bypass Impact Sandbox

27. pattern occurrence counts derive from actual incidents

28. prevention recommendation requires recurrence threshold

29. prevention recommendation is not executable

30. memory-preserving reset retains Operational Memory

31. full reset removes Operational Memory

32. multiple active incidents remain independently addressable

33. contract for cluster A cannot authorise cluster B

34. execution for cluster A does not mutate unrelated cluster state

35. audit contains full successful trust chain

36. audit contains failed verification and rollback

37. audit contains human review decision

38. analytics distinguish incidents from exceptions

39. compression ratio is calculated correctly

40. autonomous rate uses incident outcomes rather than exception count

41. no-confident-root-cause path remains unresolved

42. Phase 1 flagship still works

43. Phase 2 propagation still works

44. Phase 3 correlation still works

45. Phase 4 safety and sandbox still work

46. Phase 5 success execution still works

47. Phase 5 verification failure still works

48. no n8n integration exists

49. no FastAPI wrapper exists

50. no real secrets or banking connections exist

Run:

python -m unittest discover -s tests -v

Run:

python -W error::ResourceWarning -m unittest discover -s tests -v

All tests must pass.


==================================================
PART 45 - PRESENTATION ACCEPTANCE DEMO A
==================================================

SHARED ROOT CAUSE

1. Start from healthy environment.

2. Trigger DataHub incident.

3. Reach 23 exceptions.

4. Analyse.

5. Get 1 cluster.

6. Identify DataHub.

7. Generate contract.

8. Pass safety.

9. Pass simulation.

10. Execute A1 controlled remediation.

11. Recover affected services.

12. Verify.

13. Resolve.

14. Create memory record.

Show:

23 exceptions

to

1 root cause

to

1 verified remediation.


==================================================
PART 46 - PRESENTATION ACCEPTANCE DEMO B
==================================================

ISOLATED FAILURE

1. Trigger Merchant Settlement local failure.

2. See 1 exception.

3. Analyse.

4. See SINGLETON.

5. Show:

NO SHARED ROOT CAUSE DETECTED.

6. Diagnose local failure.

7. Generate A2 restart contract.

8. Pass technical safety conditions.

9. Require human authority.

10. Approve from Review Centre.

11. Execute restart.

12. Verify.

13. Resolve.

This proves the product does not require an exception storm to work.


==================================================
PART 47 - PRESENTATION ACCEPTANCE DEMO C
==================================================

MULTIPLE ROOT CAUSES

1. Trigger concurrent-incident scenario.

2. Observe several exceptions.

3. Analyse.

4. See at least two independent clusters.

5. Show different root causes.

6. Confirm the system does not merge them.

7. Open each cluster independently.

No need to execute both during the live pitch unless desired.


==================================================
PART 48 - PRESENTATION ACCEPTANCE DEMO D
==================================================

AMBIGUOUS EVIDENCE

1. Trigger ambiguous scenario.

2. Analyse.

3. See competing hypotheses.

4. Confidence remains below threshold.

5. No autonomous Resolution Contract path is permitted.

6. Case enters Review Centre.

7. Show missing evidence.

8. Request more evidence.

9. Simulate new evidence arriving.

10. Reanalyse.

This demonstrates fail-closed behaviour.


==================================================
PART 49 - PRESENTATION ACCEPTANCE DEMO E
==================================================

OPERATIONAL MEMORY

1. Resolve DataHub pattern successfully.

2. Reset current scenario while preserving memory.

3. Trigger new DataHub recurrence with new incident ID.

4. Analyse.

5. See similar verified incident.

6. Show previous remediation and verification outcome.

7. Continue through normal safety controls.

8. Repeat until configured recurrence threshold is reached.

9. Show prevention recommendation.

Final message:

The system does not only recover from recurring incidents.

It learns enough verified history to tell operations when the recurring failure itself should be prevented.


==================================================
PART 50 - FINAL PHASE 6 PRODUCT MESSAGE
==================================================

The completed Codex product should support this statement:

Exception Genome does not assume every alert is separate, and it does not assume every alert is connected.

It determines which failures belong together, which are isolated, which remain uncertain and which have happened before.

It finds the root cause, governs the proposed action, tests the impact, requires the right authority, executes only when permitted, independently verifies the result and records verified operational knowledge for the future.


==================================================
PART 51 - STRICT BOUNDARY
==================================================

DO NOT IMPLEMENT:

n8n

FastAPI

external workflow orchestration

real OCBC APIs

real customer data

real credentials

production authentication

production deployment

actual financial actions

This remains a synthetic proof-of-concept.

Phase 6 completes the core Codex product.

Integration comes later.


==================================================
PART 52 - COMPLETION REPORT
==================================================

When Phase 6 is complete, create:

Phase_6_Report.md

Include:

- project tree
- files added
- files modified
- database changes
- clustering generalisation
- singleton logic
- multi-cluster logic
- ambiguous-root-cause logic
- Human Review architecture
- reviewer authority rules
- Operational Memory architecture
- similarity algorithm
- pattern aggregation
- Prevention Engine
- complete Audit Trail
- analytics
- Demo Mode
- reset behaviour
- tests
- full test results
- exact run command
- exact demo sequences A through E
- known limitations

Also create:

Exception_Genome_Phase_6.zip

containing the complete project.

Do not begin n8n integration.

Do not begin FastAPI work.

Stop after Phase 6.