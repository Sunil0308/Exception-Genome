import streamlit as st
from core.database import snapshot, reset
from core.service_graph import figure, build_graph
from simulator.incident_scenarios import start, advance
from core.analysis import load
from core.execution_readiness import READY, execution_readiness
from ui.components import analysis_control, summary

@st.fragment(run_every=0.7)
def command_centre():
    if st.session_state.running:
        if not advance():
            st.session_state.running = False
    state = snapshot()
    analysis = load()
    services, incidents, exceptions = state['services'], state['incidents'], state['exceptions']
    healthy = sum(s['status']=='HEALTHY' for s in services)
    active = len([e for e in exceptions if e['status']=='ACTIVE'])
    cols = st.columns(6)
    for col, label, value in zip(cols,
        ['Active exceptions','Active incidents','Healthy services','Root causes identified','Auto-resolved','Mean resolution time'],
        [active,len(incidents),f'{healthy}/24',len(analysis['root_cause_analyses']),'0','—']):
        col.metric(label,value)
    st.caption(f"System health: {'HEALTHY' if healthy==24 else 'DEGRADED'} · Human escalations: 0 · Graph connections run from upstream dependencies to downstream consumers.")
    a,b,c = st.columns([1,1,3])
    if a.button('Simulate Incident',type='primary',disabled=bool(incidents),width='stretch'):
        start()
        st.session_state.running = True
        st.rerun()
    if b.button('Pause' if st.session_state.running else 'Resume', disabled=not incidents or active>=23,width='stretch'):
        st.session_state.running = not st.session_state.running
        st.rerun()
    if c.button('Reset synthetic demo'):
        reset()
        st.session_state.running = False
        st.rerun()
    if incidents:
        st.progress(active/23, text=f'Incident propagation · {active}/23 exceptions observed')
        st.warning('INC-2026-001 | ' + incidents[0]['status'])
        if active == 23:
            analysis_control(state)
            summary(analysis)
            decision = execution_readiness(incidents[0]['id'])
            if decision['status'] == READY:
                projected = len(decision['simulation']['projected_recoveries'])
                st.success(f'READY FOR CONTROLLED EXECUTION | Safety APPROVED | {projected}/{active} projected recovery')
                st.caption(f'1 validated remediation | {active} live exceptions ACTIVE | Live service failures remain open.')
    else:
        st.success('All 24 services healthy. No active incidents.')
    st.subheader('Service dependency map')
    st.plotly_chart(figure(services),width='stretch',key='dependency-map')
    st.subheader('Service health')
    graph = build_graph(services)
    rows = [{'Service':s['name'],'Domain':s['domain'],'Status':s['status'],
             'Upstream':', '.join(graph.nodes[n]['name'] for n in graph.predecessors(s['id'])) or 'None',
             'Downstream':', '.join(graph.nodes[n]['name'] for n in graph.successors(s['id'])) or 'None',
             'Last successful run':s['last_success'], 'Recent change':s['recent_change'] or 'None',
             'Error':s['error_state'] or 'None',
             'Current incident': ', '.join(sorted({e['incident_id'] for e in exceptions if e['service_id']==s['id']})) or 'None'} for s in services]
    st.dataframe(rows,width='stretch',hide_index=True)
    st.subheader('Exception activity')
    if exceptions:
        names = {s['id']:s['name'] for s in services}
        st.dataframe([{'Time':e['timestamp'],'Exception':e['id'],'Service':names[e['service_id']],
                       'Error':e['error_code'],'Message':e['error_message'],'Severity':e['severity'],
                       'Business impact':e['business_impact']} for e in reversed(exceptions)],width='stretch',hide_index=True)
    else:
        st.caption('No exceptions detected.')






