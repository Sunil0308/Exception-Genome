import streamlit as st

from core.action_registry import AUTONOMY_CLASSES, RESTART
from core.analysis import load
from core.database import snapshot
from core.execution_readiness import READY, execution_readiness, record_readiness
from core.impact_simulator import run_impact_simulation
from core.resolution_contract import create_contract
from core.safety_gate import evaluate_safety_gate


def render():
    st.header('Resolution Centre')
    state = snapshot()
    names = {service['id']: service['name'] for service in state['services']}
    incident_ids = [row['id'] for row in state['incidents'] if row['status'] == 'DIAGNOSED']
    if not incident_ids:
        st.info('Complete analysis in the Command Centre to open the Resolution Centre.')
        return
    incident_id = st.selectbox('Diagnosed incident', incident_ids)
    analysis = load(incident_id=incident_id)
    roots = analysis['root_cause_analyses']
    if len(roots) != 1:
        st.info('Resolution planning requires one identified root cause.')
        return
    root = roots[0]
    cluster = analysis['correlation_clusters'][0]
    decision = execution_readiness(incident_id)
    contract = decision['contract']

    with st.container(border=True):
        st.subheader('Trust chain')
        stages = (
            ('Diagnosis', 'Verified evidence', bool(root)),
            ('Resolution contract', f'Version {contract.contract_version}' if contract else 'Pending',
             bool(decision.get('integrity'))),
            ('Safety Gate', decision.get('safety_status', 'PENDING'), decision.get('safety_status') == 'APPROVED'),
            ('Impact Sandbox', decision.get('simulation_status', 'PENDING'), decision.get('simulation_status') == 'PASS'),
            ('Ready', decision['status'].replace('_', ' '), decision['status'] == READY),
        )
        for column, (label, status, complete) in zip(st.columns(5), stages):
            column.markdown(f"**{'✓' if complete else '○'} {label}**")
            column.caption(status)

    st.subheader('1. Diagnosis Snapshot')
    for column, (label, value) in zip(st.columns(5), (
        ('Exceptions', len(cluster['members'])), ('Correlated clusters', len(analysis['correlation_clusters'])),
        ('Root causes', len(roots)), ('Root-cause evidence', f"{root['confidence'] * 100:.1f}/100"),
        ('Correlation', f"{cluster['score']:.1f}/100"),
    )):
        column.metric(label, value)
    st.write(root['root_cause_service'])

    st.subheader('2. Proposed Remediation')
    left, right = st.columns(2)
    left.markdown('**Analysis recommendation**')
    left.write(root['recommended_action'])
    right.markdown('**Allowlisted controlled action**')
    if contract:
        right.code(contract.action_type)
        right.write(f"Target · {names.get(contract.target_service, contract.target_service)}")
        if contract.action_parameters:
            right.json(contract.action_parameters)
        right.write(f'{contract.autonomy_class} · {AUTONOMY_CLASSES[contract.autonomy_class]}')
    else:
        right.caption('Generate a contract to see the proposed controlled action.')

    st.subheader('3. Resolution Contract')
    candidate = st.radio('Remediation candidate', ['Approved reference activation', 'Aggressive shared authentication restart'], horizontal=True)
    if st.button('Generate Resolution Contract', type='primary'):
        create_contract(incident_id, unsafe_demo=candidate.startswith('Aggressive'))
        record_readiness(incident_id)
        st.rerun()
    if not contract:
        return
    st.write(f'Version {contract.contract_version} · SHA-256')
    st.code(contract.contract_hash)
    st.write(contract.root_cause)
    for title, value in (
        ('Frozen evidence snapshot', contract.evidence_snapshot),
        ('Required preconditions', contract.required_preconditions),
        ('Expected postconditions', contract.expected_postconditions),
        ('Rollback plan', contract.rollback_plan),
        ('Authority scope', {**contract.authority_scope, 'maximum_blast_radius': contract.maximum_blast_radius}),
    ):
        with st.expander(title):
            st.json(value)

    st.subheader('4. Safety Gate')
    if st.button('Evaluate Safety Gate'):
        evaluate_safety_gate(incident_id)
        record_readiness(incident_id)
        st.rerun()
    safety = decision['safety']
    if safety:
        status = decision['safety_status']
        st.markdown(f"**{status.replace('_', ' ')}**")
        passed = sum(rule['result'] == 'PASS' for rule in safety['rules'])
        st.caption(f'{passed} / {len(safety["rules"])} rules passed')
        st.dataframe([
            {'Rule': r['rule_id'], 'Name': r['name'], 'Result': r['result'],
             'Evidence': str(r['evidence']), 'Failure reason': r['failure_reason']} for r in safety['rules']
        ], hide_index=True)
        if status == 'APPROVED':
            st.success('Approved for impact simulation')
        elif status in ('BLOCKED', 'HUMAN_REVIEW_REQUIRED'):
            st.warning('Autonomous remediation blocked. Human review required.')

    st.subheader('5. Impact Sandbox')
    st.caption('Synthetic state-based projection. Live service and exception states are displayed in Command Centre.')
    if st.button('Run Impact Simulation', disabled=decision['safety_status'] != 'APPROVED'):
        run_impact_simulation(incident_id)
        record_readiness(incident_id)
        st.rerun()
    if contract.action_type == RESTART and decision['safety_status'] == 'BLOCKED':
        st.caption('This preset can be projected for the demonstration after the Safety Gate blocks it.')
        if st.button('Run isolated unsafe demonstration'):
            run_impact_simulation(incident_id, unsafe_demo=True)
            record_readiness(incident_id)
            st.rerun()
    simulation = decision['simulation']
    if simulation:
        recovered = len(simulation['projected_recoveries'])
        unresolved = len(simulation['projected_unresolved'])
        st.markdown(f'### {recovered} / {recovered + unresolved} projected recovery')
        for column, (label, count) in zip(st.columns(5), (
            ('Affected services', recovered + unresolved), ('Projected unresolved', unresolved),
            ('New failures', len(simulation['new_failures'])), ('Policy violations', len(simulation['policy_violations'])),
            ('Unexpected impacts', len(simulation['unexpected_impacts'])),
        )):
            column.metric(label, count)
        st.write(f"**{decision['simulation_status']}** · {simulation['reason']}")
        st.write('Root cause projected resolved · ' + ('Yes' if simulation['root_cause_resolved'] else 'No'))
        st.dataframe([{'Service': key, **value} for key, value in simulation['projected_service_states'].items()],
                     hide_index=True)

    st.subheader('6. Execution Readiness')
    for column, (label, value) in zip(st.columns(4), (
        ('Contract', 'VALID' if decision['integrity'] else 'INVALID'),
        ('Safety Gate', decision['safety_status']), ('Impact Sandbox', decision['simulation_status']),
        ('State', 'STALE' if 'STALE' in (decision['safety_status'], decision['simulation_status'])
         or not decision['diagnosis_current'] else 'CURRENT'),
    )):
        column.metric(label, value)
    st.markdown(f"### {decision['status'].replace('_', ' ')}")
    st.write(decision['reason'])
    if decision['status'] == READY:
        st.write(f'{contract.proposed_action} · {len(simulation["projected_recoveries"])} projected recoveries')
        st.code(contract.contract_hash)
        st.write(f"Rollback · Restore {contract.rollback_plan['credential_version']} and escalate if unexpected behaviour occurs.")
    st.markdown('**Execution is intentionally disabled in Phase 4.**')


