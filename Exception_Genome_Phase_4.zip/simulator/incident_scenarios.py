"""Scenario configuration; wrappers preserve the existing public API."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    incident_id: str
    title: str
    start_time: str
    source_service: str
    triggering_event: str
    recent_change: dict
    exception_templates: dict
    domain_templates: dict
    severity_rules: dict
    failed_domains: tuple
    propagation_rule: str = 'descendants'
    timing_interval: int = 8
    first_delay: int = 10

DATAHUB = Scenario(
    'datahub-credential', 'INC-2026-001', 'DataHub Credential Failure',
    '2026-11-17T09:00:00', 'datahub', 'CREDENTIAL_EXPIRED',
    {'service_id':'datahub', 'timestamp':'2026-11-17T08:59:00',
     'type':'CREDENTIAL_ROTATION_FAILED', 'credential_state':'EXPIRED',
     'description':'DataHub credential rotation failed at 08:59'},
    {'datahub':('AUTH-401-DH','Credential rejected during service authentication'),
     'revenue':('SRC-201','Required reporting source unavailable'),
     'daily_recon':('REC-104','Expected source records not received'),
     'merchant':('REF-301','Reference data lookup unavailable'),
     'statement':('CUS-220','Customer transaction data retrieval failed'),
     'finance':('EXP-510','Finance export incomplete due to missing source dataset'),
     'card':('SET-407','Settlement enrichment dependency unavailable')},
    {'Payments':('SET','Processing blocked by missing upstream data'),
     'Reconciliation':('REC','Expected source records not received'),
     'Reporting':('SRC','Required reporting source unavailable'),
     'Customer Operations':('CUS','Customer data retrieval failed'),
     'Shared Infrastructure':('DEP','Dependent data operation unavailable')},
    {'source':'CRITICAL','downstream':'HIGH'}, ('Reporting','Reconciliation'))
INCIDENT_ID = DATAHUB.incident_id

def start(path=None, scenario=DATAHUB):
    from simulator.engine import start as run
    from core.database import DEFAULT_DB
    return run(path or DEFAULT_DB, scenario)

def advance(path=None, scenario=DATAHUB):
    from simulator.engine import advance as run
    from core.database import DEFAULT_DB
    return run(path or DEFAULT_DB, scenario)

SCENARIOS = {DATAHUB.incident_id: DATAHUB}


def get_scenario(incident_id):
    return SCENARIOS.get(incident_id)
