Continue the existing **OCBC Exception Genome** project.

Phases 1–3 are implemented and working.

DO NOT rebuild the application.

DO NOT implement actual remediation execution, service recovery, final post-action verification, Operational Memory, Prevention Engine or a complete Human Review workflow.

This task consists of:

1. two required Phase 3 architecture corrections
2. Resolution Contract
3. deterministic Safety Gate
4. Impact Sandbox
5. execution-readiness decision

This is **Phase 4 only**.

The core product progression is now:

EXCEPTION STORM

→ EXCEPTION GENOME

→ ROOT CAUSE

→ RESOLUTION CONTRACT

→ SAFETY GATE

→ IMPACT SANDBOX

→ READY FOR CONTROLLED EXECUTION

Actual execution belongs to Phase 5.

---

# CORE PHASE 4 MESSAGE

Phase 3 answered:

**What actually caused these 23 exceptions?**

Phase 4 answers:

**Even if the diagnosis is correct, should an autonomous agent be permitted to act?**

The application must demonstrate that:

**AI may recommend an action. AI cannot grant itself permission to execute that action.**

The permission decision must come from deterministic controls.

The second message is:

**A proposed fix should be tested before it touches the operational environment.**

The final Phase 4 demo message is:

# Diagnose → Contract → Govern → Simulate

Do not mutate the live synthetic service environment in this phase.

---

# PART 0 — REQUIRED PHASE 3 ARCHITECTURE FIXES

Complete these before adding Phase 4 functionality.

## 0.1 Remove DATAHUB hardcoding from analysis

The current analysis pipeline is coupled directly to the DataHub scenario.

Refactor the following concepts to be incident-aware:

- ready()
- analyse()
- analysis persistence
- correlation cluster IDs
- root-cause analysis IDs

Required interface:

analyse(incident_id)

ready(state, incident_id)

The analyser must:

1. locate the requested incident
2. locate its scenario definition
3. retrieve ONLY exceptions belonging to that incident
4. determine expected propagation from that scenario
5. analyse ONLY that incident
6. persist results against that incident

Do not read every ACTIVE exception globally.

---

## 0.2 Introduce scenario registry

Create a scenario registry.

Example:

SCENARIOS = {
    "INC-2026-001": DATAHUB
}

Provide helper:

get_scenario(incident_id)

Future scenarios must be addable without modifying the analysis engine.

Do not implement all future scenarios yet.

The existing DataHub scenario must behave identically after this refactor.

---

## 0.3 Make analytical IDs incident-safe

The current cluster ID:

EG-001

cannot safely exist for multiple incidents if it remains a globally unique database primary key.

Use incident-scoped IDs.

Example:

EG-INC-2026-001-001

or implement a proper internal unique identifier while keeping a short display label.

Apply the same principle to:

- root-cause analysis
- resolution contracts
- safety evaluations
- simulations

Do not create future identifier collisions.

---

# PART 1 — FIX ERROR-COMPATIBILITY LOGIC

The current compatibility structure effectively treats all known normalized error families as mutually compatible.

Replace this with an explicit causal compatibility model.

The following families currently exist:

AUTHENTICATION_FAILURE

UPSTREAM_DATA_UNAVAILABLE

DEPENDENCY_FAILURE

PROCESSING_BLOCKED

MISSING_SOURCE_DATA

Compatibility must depend on the relationship between services.

Do not simply say:

every family can match every family.

Example causal relationships:

AUTHENTICATION_FAILURE upstream

may plausibly cause:

- UPSTREAM_DATA_UNAVAILABLE downstream
- DEPENDENCY_FAILURE downstream
- MISSING_SOURCE_DATA downstream
- PROCESSING_BLOCKED downstream

UPSTREAM_DATA_UNAVAILABLE upstream

may plausibly cause:

- MISSING_SOURCE_DATA downstream
- DEPENDENCY_FAILURE downstream
- PROCESSING_BLOCKED downstream

DEPENDENCY_FAILURE upstream

may plausibly cause:

- DEPENDENCY_FAILURE downstream
- PROCESSING_BLOCKED downstream

Identical families may remain compatible.

Implement this as a documented directional compatibility structure.

The correlation engine must consider:

source family

target family

AND

dependency direction.

Sibling exceptions may still correlate through a proven common ancestor, but should not automatically receive full causal error-relationship points merely because both families exist in a global set.

Update tests.

The flagship incident must still form one cluster if the operational evidence legitimately supports it.

Do not manipulate weights merely to force the expected outcome.

---

# PART 2 — RESOLUTION PLANNING MODEL

Create:

core/resolution_contract.py

The Root Cause Agent currently produces a recommendation.

That recommendation must NOT directly become an executable action.

Introduce a deterministic translation layer between:

AI recommendation

and

approved operational action type.

For the flagship incident, the root cause is:

DataHub credential expiry following unsuccessful credential rotation.

Do NOT model the autonomous system as generating a new bank credential.

Instead create a safe synthetic action representing restoration from a previously approved credential version.

Use:

Action Type:

ACTIVATE_APPROVED_CREDENTIAL_REFERENCE

Target:

DataHub API

Synthetic parameter:

credential_version = DH-v18

Previous:

DH-v17

This represents switching the service to an already approved replacement credential inside the synthetic environment.

It does NOT represent generating, stealing, revealing or rotating a real credential.

---

# PART 3 — ACTION REGISTRY

Create:

core/action_registry.py

Define every remediation type the autonomous system understands.

Each action definition must contain:

- action_type
- human-readable name
- description
- permitted target types
- autonomy_class
- reversibility
- maximum allowed scope
- requires_simulation
- required_evidence
- allowed_parameters
- forbidden_parameters
- rollback_action
- default_risk
- autonomous_execution_permitted

Create at least these synthetic actions:

ACTIVATE_APPROVED_CREDENTIAL_REFERENCE

RESTART_SINGLE_SERVICE

RETRY_FAILED_JOB

NO_ACTION

ESCALATE

Also create one deliberately unsupported/high-risk action:

ROTATE_OR_CREATE_CREDENTIAL

For that action:

autonomous_execution_permitted = false

This is important.

If an AI ever recommends:

"Create a new credential"

or:

"Rotate all credentials"

the Safety Gate must block autonomous action.

The model must distinguish:

**AI recommendation**

from:

**allowlisted operational action**

---

# PART 4 — AUTONOMY CLASSES

Create clear autonomy classes.

Example:

A0 — ADVISORY ONLY

No autonomous state change allowed.

A1 — CONTROLLED / REVERSIBLE

Single-target, allowlisted, reversible synthetic operational action.

A2 — CONDITIONAL

Higher blast radius or stronger approval requirement.

A3 — PROHIBITED AUTONOMOUSLY

Must always require human review.

For the flagship action:

ACTIVATE_APPROVED_CREDENTIAL_REFERENCE

use an appropriate controlled/reversible class.

Do not pretend all credential operations are low-risk.

Explicitly distinguish activating a pre-approved synthetic credential reference from creating or rotating credentials.

---

# PART 5 — RESOLUTION CONTRACT

The Resolution Contract is one of the core innovations.

Create a structured ResolutionContract model.

At minimum include:

contract_id

incident_id

cluster_id

analysis_id

created_at

root_cause

root_cause_service

root_cause_evidence_score

correlation_score

proposed_action

action_type

target_service

action_parameters

autonomy_class

risk_class

evidence_snapshot

required_preconditions

expected_postconditions

rollback_plan

authority_scope

maximum_blast_radius

contract_version

contract_hash

status

The contract must clearly separate:

DIAGNOSIS

EVIDENCE

ACTION

PRECONDITIONS

EXPECTED RESULT

ROLLBACK

AUTHORITY

---

# PART 6 — FLAGSHIP RESOLUTION CONTRACT

For INC-2026-001 construct a contract conceptually equivalent to:

INCIDENT

INC-2026-001

ROOT CAUSE

DataHub API credential reference remained expired following failed credential rotation.

ROOT-CAUSE EVIDENCE SCORE

calculated Phase 3 score

CORRELATION

calculated Phase 3 score

PROPOSED CONTROLLED ACTION

Activate approved credential reference DH-v18 for DataHub API.

TARGET

DataHub API

AUTONOMY CLASS

A1 — CONTROLLED / REVERSIBLE

PRECONDITIONS

- incident status = DIAGNOSED
- DataHub is currently FAILED
- authentication context = CREDENTIAL_EXPIRED
- failed credential change evidence exists
- DataHub is the strongest root-cause candidate
- evidence score exceeds configured threshold
- no material contradictory evidence exists
- replacement reference DH-v18 exists in synthetic approved-reference registry
- replacement reference is marked APPROVED
- DH-v18 is not expired
- no equivalent remediation has already executed
- action affects only the declared target configuration
- action type is allowlisted for controlled autonomy

EXPECTED POSTCONDITIONS

- DataHub authentication becomes valid
- DataHub service enters recovery
- downstream dependency connectivity can resume
- affected downstream services become eligible for recovery
- active exception count begins decreasing

ROLLBACK

Restore previous credential reference DH-v17 and escalate to human reviewer if unexpected behaviour occurs.

Do NOT execute any of these changes during Phase 4.

---

# PART 7 — TAMPER-EVIDENT CONTRACT

This is mandatory.

Canonicalise the contract fields that affect safety.

Generate:

contract_hash

using SHA-256 over deterministic canonical JSON.

The hash must include at least:

- incident ID
- diagnosis/root cause
- evidence snapshot
- proposed action
- action parameters
- preconditions
- expected postconditions
- authority scope
- risk/autonomy classification
- rollback plan

Do NOT include volatile presentation-only fields that would make identical contracts randomly hash differently.

Display:

CONTRACT VERSION

CONTRACT HASH

Example:

Version 1

SHA-256

7c81...e94a

The point is not blockchain.

Do not call this blockchain.

The purpose is:

**Safety approval applies to one exact diagnosis + evidence + action combination.**

If any safety-relevant part of the contract changes:

- create a new version/hash
- invalidate previous Safety Gate result
- invalidate previous Impact Sandbox result
- require reassessment

Implement and test this.

---

# PART 8 — EVIDENCE SNAPSHOT

A Resolution Contract must freeze the evidence that existed when the proposed action was created.

Store:

- root-cause analysis result
- correlation score
- relevant Exception Genome signatures
- DataHub service state
- recorded change event
- affected-service count
- conflicting evidence
- alternative hypotheses
- timestamp of snapshot

Do not store only human-readable strings.

Store structured evidence.

This allows later audit to answer:

**What did the system know when this decision was made?**

---

# PART 9 — SYNTHETIC APPROVED-CREDENTIAL REGISTRY

Create a synthetic data structure representing approved credential references.

Do not store real secrets.

Never store credential values.

Example:

DH-v17

status:
EXPIRED

approved:
true

created:
synthetic timestamp

DH-v18

status:
VALID

approved:
true

created:
synthetic timestamp

The application should only reference identifiers.

No secret material should exist anywhere.

The proposed action may switch the DataHub synthetic reference:

DH-v17 → DH-v18

only in simulation during Phase 4.

The live service state must remain unchanged.

---

# PART 10 — DETERMINISTIC SAFETY GATE

Create:

core/safety_gate.py

The Safety Gate must be completely independent of the LLM/root-cause agent.

It must evaluate the Resolution Contract using deterministic rules.

Each rule must have:

rule_id

name

description

severity

result

evidence

failure_reason

Results:

PASS

FAIL

NOT_APPLICABLE

The overall Safety Gate result must be:

APPROVED

BLOCKED

HUMAN_REVIEW_REQUIRED

Fail closed.

Unknown or missing required evidence must never default to PASS.

---

# PART 11 — SAFETY RULES FOR FLAGSHIP INCIDENT

Implement explicit rules.

At minimum:

SG-001

Valid diagnosis exists.

SG-002

Contract references current diagnosis version.

SG-003

Contract hash is valid.

SG-004

Root-cause evidence score exceeds configured threshold.

SG-005

Correlation evidence exceeds configured threshold.

SG-006

No material conflicting evidence exists.

SG-007

Target service is the identified root-cause service.

SG-008

Action type exists in Action Registry.

SG-009

Action is permitted for autonomous controlled execution.

SG-010

Action parameters match the allowlist.

SG-011

Approved replacement reference exists.

SG-012

Replacement reference status = VALID.

SG-013

Current DataHub reference is confirmed expired.

SG-014

Incident has not already received equivalent remediation.

SG-015

Declared scope does not exceed action maximum.

SG-016

Rollback plan exists.

SG-017

Required evidence is complete.

SG-018

Incident remains operationally unresolved.

Do not hardcode the overall answer APPROVED.

Calculate it from rule outcomes.

---

# PART 12 — POLICY DECISION EXPLANATION

The UI must show EXACTLY why an action is approved or denied.

Example:

SAFETY GATE

18 / 18 rules passed

Decision:

APPROVED FOR IMPACT SIMULATION

Then a table:

Rule

Result

Evidence

SG-001 Diagnosis exists PASS

SG-002 Analysis current PASS

...

If one rule fails:

SG-011 Approved credential unavailable FAIL

Overall:

AUTONOMOUS REMEDIATION BLOCKED

Reason:

No valid approved replacement credential reference exists.

Required outcome:

Human review.

No vague:

"AI confidence too low."

Every denial must map to concrete deterministic policy.

---

# PART 13 — SAFETY GATE MUST CATCH UNSAFE AI OUTPUT

Create tests where the recommendation is malicious, incorrect or out of authority.

Examples:

AI suggests:

ROTATE_OR_CREATE_CREDENTIAL

Result:

BLOCKED

Reason:

Action is prohibited from autonomous execution.

AI targets:

Authentication Service

when DataHub is diagnosed root cause.

Result:

BLOCKED

Reason:

Target does not match verified root-cause service.

AI parameters contain:

unknown credential reference

Result:

BLOCKED.

AI asks for:

multiple service modifications

when action scope permits one.

Result:

BLOCKED.

This must demonstrate:

**The agent cannot expand its own authority.**

---

# PART 14 — IMPACT SANDBOX

Create:

core/impact_simulator.py

UI name:

# Impact Sandbox

Do NOT claim this is an actual OCBC digital twin.

It is:

a synthetic state-based simulation of the proposed operational remediation.

It must use a deep copy / isolated representation of:

- services
- dependency graph
- incident state
- current exceptions
- synthetic configuration references

The simulation must NEVER modify:

- services table
- exception status
- incident status
- live synthetic credential reference
- Phase 3 evidence

during its calculation.

Prove this in tests.

---

# PART 15 — FLAGSHIP IMPACT SIMULATION

Input:

Resolution Contract

Action:

ACTIVATE_APPROVED_CREDENTIAL_REFERENCE

DataHub:

DH-v17 → DH-v18

Simulate:

1. replacement reference becomes active in sandbox
2. DataHub authentication condition becomes valid
3. DataHub becomes eligible for recovery
4. dependency graph is traversed downstream
5. impacted services are reevaluated
6. projected recoveries are calculated
7. unexpected impacts are calculated
8. policy violations are checked

Expected result:

Affected services evaluated:
23

Projected recovered:
23

Projected unresolved:
0

New failures:
0

Policy violations:
0

Unexpected dependency impact:
0

Result:

PASS

Display:

# 23 / 23 projected recovery

---

# PART 16 — IMPACT SANDBOX MUST NOT MAGICALLY GUARANTEE SUCCESS

The simulation requires explicit operational rules.

Do not write:

if flagship:
    return 23

Instead model:

- root service state
- dependency satisfaction
- action effect
- downstream graph traversal
- projected service eligibility

If a downstream service still has another failed required dependency, it must remain projected unresolved.

If the remediation introduces a new failed dependency, show it.

The projected result must arise from the graph and simulated state.

---

# PART 17 — UNSAFE SANDBOX DEMONSTRATION

Create at least one deliberate alternative remediation candidate for demonstration.

Example:

AGGRESSIVE SHARED AUTH RESTART

Target:

Authentication Service

Effect in sandbox:

- DataHub root problem remains unresolved
- Authentication Service becomes temporarily unavailable
- additional authentication dependency risk is introduced

Expected:

Root cause resolved:
NO

New failure introduced:
YES

Impact Sandbox:

FAIL

The purpose is to show that an action that sounds operationally plausible can make the environment worse.

This candidate must NEVER execute against live synthetic state.

---

# PART 18 — SANDBOX RESULT MODEL

Persist:

simulation_id

contract_id

contract_hash

started_at

completed_at

input_state_digest

action

target

projected_recoveries

projected_unresolved

new_failures

policy_violations

unexpected_impacts

projected_service_states

result

reason

output_state_digest

Result:

PASS

FAIL

INCONCLUSIVE

If evidence or simulation logic cannot determine the outcome:

INCONCLUSIVE

must NOT mean PASS.

---

# PART 19 — SIMULATION INVALIDATION

A simulation is valid ONLY for the exact contract hash it evaluated.

If:

- contract changes
- proposed action changes
- parameters change
- root-cause evidence changes
- relevant operational state changes

the previous sandbox result must become:

STALE

and may not support execution readiness.

Implement deterministic state digests.

---

# PART 20 — EXECUTION READINESS

Create:

core/execution_readiness.py

This does NOT execute anything.

It combines:

Resolution Contract

Safety Gate

Impact Sandbox

Output states:

NOT_READY

BLOCKED

HUMAN_REVIEW_REQUIRED

READY_FOR_CONTROLLED_EXECUTION

To return:

READY_FOR_CONTROLLED_EXECUTION

all of the following must hold:

- current contract exists
- contract hash valid
- diagnosis current
- Safety Gate = APPROVED
- Impact Sandbox = PASS
- simulation contract hash matches current contract hash
- simulated input-state digest matches current relevant state
- no new material evidence has appeared

Display a final card:

# READY FOR CONTROLLED EXECUTION

with:

Action

Target

Contract hash

Safety Gate

Impact Sandbox

Projected recovery

Rollback

But:

DO NOT PROVIDE AN EXECUTE BUTTON.

Actual execution belongs to Phase 5.

---

# PART 21 — DATABASE

Add only the tables required for Phase 4.

Suggested:

resolution_contracts

safety_evaluations

impact_simulations

execution_readiness

approved_resource_references

Use proper foreign keys.

Persist JSON payloads where appropriate but retain searchable identifiers/status columns.

Do NOT create:

executions

verification_results

operational_memory

prevention_actions

Those belong to later phases.

---

# PART 22 — RESOLUTION CENTRE UI

Create:

ui/resolution_centre.py

Add navigation:

Resolution Centre

The page should only become meaningful after an incident has been DIAGNOSED.

Visual structure:

## 1. Diagnosis Snapshot

Show:

23 exceptions

1 correlated cluster

1 root cause

DataHub API

Root-cause evidence score

Correlation score

---

## 2. Proposed Remediation

Show:

AI/analysis recommendation

and separately:

CONTROLLED ACTION

ACTIVATE_APPROVED_CREDENTIAL_REFERENCE

Target:
DataHub API

Reference:
DH-v18

Autonomy:
A1 Controlled / Reversible

Make the distinction visually clear.

---

## 3. Resolution Contract

Show:

contract version

contract hash

root cause

evidence

preconditions

expected postconditions

rollback plan

authority scope

---

## 4. Safety Gate

Button:

Evaluate Safety Gate

Show every rule.

Show:

APPROVED

or

BLOCKED

or

HUMAN REVIEW REQUIRED

---

## 5. Impact Sandbox

Only enabled if the action is eligible for simulation.

Button:

Run Impact Simulation

Show before/after projected state.

Use graph visualisation if useful.

Show:

23 affected

23 projected recovery

0 unresolved

0 new failures

Result:

PASS

---

## 6. Execution Readiness

Show:

CONTRACT

VALID

SAFETY GATE

APPROVED

IMPACT SANDBOX

PASS

STATE

CURRENT

Final:

READY FOR CONTROLLED EXECUTION

Then display:

**Execution is intentionally disabled in Phase 4.**

Do not create a fake disabled Execute button.

---

# PART 23 — TRUST CHAIN VISUAL

Create a major visual component showing:

DIAGNOSIS

✓

RESOLUTION CONTRACT

✓

SAFETY GATE

✓

IMPACT SANDBOX

✓

READY

Each stage should be traceable.

This should become one of the strongest visuals in the eventual pitch.

---

# PART 24 — COMMAND CENTRE UPDATE

Do not clutter Command Centre.

After Phase 4 completes, incident summary may show:

INC-2026-001

Status:

READY FOR EXECUTION

23 active exceptions

1 root cause

1 validated remediation

Safety:

APPROVED

Impact:

23 / 23 projected recovery

Important:

Services are STILL failed/degraded.

Exceptions are STILL active.

Nothing has actually been fixed yet.

This distinction must remain obvious.

---

# PART 25 — AUDIT EVENTS

Phase 4 actions must create audit-style records or events for:

Resolution Contract created

Contract version generated

Safety evaluation performed

Safety rule blocked

Impact simulation started

Impact simulation completed

Readiness determined

Do not yet implement the complete Phase 6 Audit Trail page if that architecture does not exist.

But make events persistable and compatible with the future audit system.

---

# PART 26 — TESTS

Preserve all existing tests.

Add tests for at least:

1. analysis works using incident_id rather than DATAHUB global assumptions

2. analysis only reads exceptions for requested incident

3. incident-safe cluster IDs cannot collide

4. compatibility is no longer universal

5. valid causal error relationships still cluster flagship incident

6. invalid error relationships do not automatically receive full points

7. Resolution Contract generated from current diagnosis

8. contract hash deterministic

9. changing action changes contract hash

10. changing evidence changes contract hash

11. old Safety Gate result invalidated after contract change

12. Action Registry blocks prohibited autonomous actions

13. wrong target blocked

14. unknown replacement reference blocked

15. missing evidence fails closed

16. valid flagship contract passes all required safety rules

17. Impact Sandbox does not modify live database state

18. flagship simulation derives 23 projected recoveries from graph/state

19. unsafe remediation introduces projected negative impact and FAILS

20. INCONCLUSIVE does not count as PASS

21. simulation tied to contract hash

22. stale state invalidates simulation

23. readiness requires both safety approval and sandbox pass

24. services remain failed/degraded after Phase 4

25. exceptions remain ACTIVE after Phase 4

26. no execution engine exists

27. no verification engine exists

28. no Operational Memory exists

Run:

python -m unittest discover -s tests -v

and:

python -W error::ResourceWarning -m unittest discover -s tests -v

All tests must pass.

---

# PART 27 — STRICT PHASE BOUNDARY

DO NOT implement:

execution engine

actual credential-reference switching in live state

service recovery

exception closure

post-action verification

Operational Memory

Prevention Engine

complete Human Review workflow

real banking integration

real secrets

LLM authority decisions

No service should recover during Phase 4.

No exception should close.

---

# PART 28 — PHASE 4 ACCEPTANCE DEMO

Phase 4 is complete only when I can perform:

1. Start healthy system.

2. Simulate INC-2026-001.

3. Reach 23 operational exceptions.

4. Analyse Exception Genomes.

5. Identify one cluster and DataHub root cause.

6. Open Resolution Centre.

7. See the AI recommendation separated from the allowlisted controlled action.

8. Generate Resolution Contract.

9. Inspect its frozen evidence snapshot.

10. Inspect contract version and hash.

11. Run Safety Gate.

12. See every rule PASS/FAIL individually.

13. Receive APPROVED for the valid controlled action.

14. Run Impact Sandbox.

15. See sandbox project 23/23 recovery with zero live state mutation.

16. See READY FOR CONTROLLED EXECUTION.

17. Switch/test the deliberately unsafe remediation.

18. See the Safety/Sandbox architecture reject it and explain why.

19. Verify live service state has still not changed.

20. Verify all 23 exceptions remain ACTIVE.

21. No Execute button exists.

---

# PART 29 — COMPLETION REPORT

When finished, provide:

- updated project tree
- architecture changes
- Phase 3 fixes performed
- directional compatibility model
- Action Registry definition
- Resolution Contract schema
- contract hashing method
- Safety Gate rules
- Impact Sandbox algorithm
- execution-readiness logic
- database changes
- tests added
- complete test results
- exact run command
- exact Phase 4 demo sequence
- known limitations

Do not begin Phase 5.