import streamlit as st
from core.database import snapshot
from core.analysis import load
from core.service_graph import analytical_figure
from ui.components import analysis_control, summary, scores, root_evidence

def render():
    state,analysis = snapshot(),load()
    exceptions = state['exceptions']
    services = {s['id']:s for s in state['services']}
    st.header('Exception Genome')
    st.metric('Exceptions detected',len(exceptions))
    st.subheader('Different symptoms')
    domains = list(dict.fromkeys(s['domain'] for s in state['services']))
    for col,domain in zip(st.columns(len(domains)),domains):
        with col:
            with st.container(border=True):
                st.caption(domain)
                example = next((e for e in exceptions if services[e['service_id']]['domain']==domain),None)
                if example:
                    st.markdown('**'+services[example['service_id']]['name']+'**')
                    st.code(example['error_code'])
                    st.write(example['error_message'])
                else:
                    st.write('No failures observed')
    analysis_control(state)
    if not analysis['root_cause_analyses']:
        st.info('Raw symptoms are available. No diagnosis has been computed.')
        return
    st.subheader('Shared operational fingerprint')
    cluster = analysis['correlation_clusters'][0]
    root = analysis['root_cause_analyses'][0]
    a,b,c = st.columns(3)
    a.metric('Shared dependency',root['root_cause_service'])
    b.metric('Different error codes',cluster['different_error_codes'])
    c.metric('Operational domains',cluster['domains'])
    st.write(cluster['common_change'].get('description','No shared recorded change'))
    st.caption(f"First observed: {services[cluster['first_failure']]['name']} | Span: {cluster['time_span_seconds']:g} simulated seconds")
    genomes = analysis['exception_genomes']
    selected = st.selectbox('Inspect operational fingerprint',genomes,format_func=lambda g:g['service_name'])
    with st.expander('Genome fields',expanded=True):
        st.json(selected,expanded=False)
    st.subheader(cluster['id'] + ' · ' + cluster['status'])
    scores(cluster)
    summary(analysis)
    st.plotly_chart(analytical_figure(state['services'],root['root_cause_service_id']),width='stretch')
    root_evidence(root)

