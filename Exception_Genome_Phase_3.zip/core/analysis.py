import json
from core.database import DEFAULT_DB,connect,snapshot
from core.service_graph import build_graph
from core.exception_genome import generate
from core.correlation_engine import correlate
from core.root_cause_agent import DeterministicRootCauseAgent
from simulator.incident_scenarios import DATAHUB
from simulator.engine import propagation_order

def load(path=DEFAULT_DB):
    with connect(path) as db:
        return {table:[json.loads(r['payload']) for r in db.execute('SELECT payload FROM '+table)]
                for table in ('exception_genomes','correlation_clusters','root_cause_analyses')}

def ready(state):
    graph = build_graph(state['services'])
    expected = len(propagation_order(graph,DATAHUB))
    return any(i['id']==DATAHUB.incident_id and i['simulation_step']==expected for i in state['incidents'])

def analyse(path=DEFAULT_DB,progress=lambda message:None):
    state = snapshot(path)
    if not ready(state):
        raise ValueError('Wait for incident propagation to complete')
    existing = load(path)
    if existing['root_cause_analyses']:
        return existing
    graph = build_graph(state['services'])
    progress('Extracting operational fingerprints...')
    genomes = [generate(e,graph) for e in state['exceptions'] if e['status']=='ACTIVE']
    progress('Comparing shared dependencies...')
    progress('Aligning event timelines...')
    clusters = correlate(genomes,graph)
    progress('Evaluating recent change events...')
    progress('Testing root-cause candidates...')
    roots = [DeterministicRootCauseAgent().analyze([g for g in genomes if g.exception_id in c['members']],graph) for c in clusters]
    with connect(path) as db:
        # One transaction: no partial diagnosis can survive an interrupted analysis.
        for g in genomes:
            db.execute('INSERT INTO exception_genomes VALUES (?,?)',(g.exception_id,json.dumps(g.to_dict())))
            db.execute('UPDATE exceptions SET genome_signature=? WHERE id=?',(g.genome_signature,g.exception_id))
        for cluster,result in zip(clusters,roots):
            db.execute('INSERT INTO correlation_clusters VALUES (?,?,?)',(cluster['id'],DATAHUB.incident_id,json.dumps(cluster)))
            db.executemany('INSERT INTO cluster_members VALUES (?,?)',[(cluster['id'],member) for member in cluster['members']])
            db.execute('INSERT INTO root_cause_analyses VALUES (?,?)',(cluster['id'],json.dumps(result)))
        db.execute("UPDATE incidents SET status='DIAGNOSED' WHERE id=?",(DATAHUB.incident_id,))
    return load(path)
