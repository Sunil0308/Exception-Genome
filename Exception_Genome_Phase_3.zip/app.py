import streamlit as st
from core.database import initialize
from ui.command_centre import command_centre
from ui.genome_view import render as genome_view
from ui.incident_investigation import render as investigation

st.set_page_config(page_title='Exception Genome', layout='wide')
initialize()
st.session_state.setdefault('running', False)
st.title('Exception Genome')
st.caption('Verified Autonomous Operations | Synthetic proof of concept | Phase 3')
st.sidebar.caption('Synthetic services and evidence. No banking systems connected.')
page = st.sidebar.radio('Workspace', ['Command Centre', 'Exception Genome', 'Incident Investigation'])
st.sidebar.caption('Diagnosis only. No remediation is authorised or executed.')
{'Command Centre': command_centre, 'Exception Genome': genome_view,
 'Incident Investigation': investigation}[page]()
