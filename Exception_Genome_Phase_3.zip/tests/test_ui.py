import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from streamlit.testing.v1 import AppTest
from core.database import DEFAULT_DB,snapshot
from simulator.incident_scenarios import advance

def tearDownModule():
    # Streamlit's test harness creates a module-level temp directory. Close it
    # explicitly too, so ResourceWarning-as-error runs are clean at shutdown.
    from streamlit.testing.v1.app_test import TMP_DIR
    target = Path(TMP_DIR.name).resolve()
    if target.is_relative_to(Path(tempfile.gettempdir()).resolve()):
        TMP_DIR.cleanup()

class UITests(unittest.TestCase):
    def test_demo_controls_and_analysis_pages(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'ui.db'
            original = sqlite3.connect
            def isolated(database,*args,**kwargs):
                return original(path if Path(database)==DEFAULT_DB else database,*args,**kwargs)
            with patch('sqlite3.connect',side_effect=isolated):
                app = AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py'),default_timeout=60).run()
                self.assertFalse(app.exception)
                self.assertEqual(app.metric[0].value,'0')
                app.button[0].click().run()
                self.assertFalse(app.exception)
                app.button[1].click().run()
                self.assertFalse(app.session_state['running'])
                self.assertEqual(app.button[1].label,'Resume')
                app.button[1].click().run()
                self.assertTrue(app.session_state['running'])
                app.session_state['running'] = False
                while advance():
                    pass
                app.run()
                self.assertEqual(app.metric[0].value,'23')
                next(b for b in app.button if b.label=='Analyse Exception Genomes').click().run()
                self.assertFalse(app.exception)
                self.assertEqual(app.metric[3].value,'1')
                self.assertEqual(snapshot()['incidents'][0]['status'],'DIAGNOSED')
                for page in ('Exception Genome','Incident Investigation','Command Centre'):
                    app.sidebar.radio[0].set_value(page).run()
                    self.assertFalse(app.exception, str(app.exception))
                next(b for b in app.button if b.label=='Reset synthetic demo').click().run()
                self.assertFalse(app.exception)
                self.assertEqual(app.metric[0].value,'0')
                self.assertEqual(app.metric[3].value,'0')
