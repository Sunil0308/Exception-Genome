from datetime import datetime, timedelta
import networkx as nx
from core.database import connect, snapshot, DEFAULT_DB
from core.service_graph import build_graph

INCIDENT_ID = 'INC-2026-001'


def start(path=DEFAULT_DB):
    with connect(path) as db:
        db.execute("INSERT OR IGNORE INTO incidents VALUES (?,?,'ACTIVE',?,0)",
                   (INCIDENT_ID, 'DataHub Credential Failure', '2026-11-17T09:00:00'))
        db.execute("UPDATE services SET recent_change=? WHERE id='datahub'",
                   ('08:59 — synthetic credential rotation failed; credential expired at 09:00',))


def advance(path=DEFAULT_DB):
    state = snapshot(path)
    graph = build_graph(state['services'])
    affected = nx.descendants(graph, 'datahub') | {'datahub'}
    order = [node for node in nx.topological_sort(graph) if node in affected]
    with connect(path) as db:
        incident = db.execute('SELECT * FROM incidents WHERE id=?', (INCIDENT_ID,)).fetchone()
        if incident is None or incident['simulation_step'] >= len(order):
            return False
        step = incident['simulation_step']
        service_id = order[step]
        service = graph.nodes[service_id]
        at = (datetime(2026,11,17,9) + timedelta(seconds=10 + step*8)).isoformat()
        category = 'AUTHENTICATION' if service_id=='datahub' else 'DEPENDENCY'
        error = 'AUTH-401-DH' if service_id=='datahub' else f'DEP-{step:03d}'
        messages = {'Payments':'Settlement or payment processing blocked by upstream data failure',
                    'Reconciliation':'Required source records unavailable; reconciliation incomplete',
                    'Reporting':'Report source unavailable; output not generated',
                    'Customer Operations':'Customer data retrieval unavailable',
                    'Shared Infrastructure':'Dependent data operation failed'}
        message = 'Expired synthetic service credential; authentication rejected' if service_id=='datahub' else messages[service['domain']]
        status = 'FAILED' if service_id=='datahub' or service['domain'] in ('Reporting','Reconciliation') else 'DEGRADED'
        db.execute('UPDATE services SET status=?,health_state=?,error_state=? WHERE id=?',
                   (status,status,message,service_id))
        db.execute('INSERT INTO exceptions (id,incident_id,service_id,timestamp,error_code,error_category,error_message,severity,business_impact) VALUES (?,?,?,?,?,?,?,?,?)',
                   (f'EX-{step+1:03d}',INCIDENT_ID,service_id,at,error,category,message,
                    'CRITICAL' if service_id=='datahub' else 'HIGH', f"{service['name']} operational output delayed"))
        db.execute('UPDATE incidents SET simulation_step=simulation_step+1 WHERE id=?', (INCIDENT_ID,))
    return True
