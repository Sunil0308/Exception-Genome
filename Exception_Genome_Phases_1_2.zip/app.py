import json
import streamlit as st
from core.database import initialize, snapshot, reset
from core.service_graph import figure, build_graph
from simulator.incident_scenarios import start, advance

st.set_page_config(page_title='Exception Genome', layout='wide')
initialize()
st.title('Exception Genome')
st.caption('Verified Autonomous Operations · Synthetic proof of concept · Phases 1–2')
st.sidebar.header('Command Centre')
st.sidebar.caption('All services, credentials and incidents are synthetic. No banking systems are connected.')
st.sidebar.info('Current scope: environment and incident propagation. Correlation and remediation are not implemented.')
if 'running' not in st.session_state:
    st.session_state.running = False

@st.fragment(run_every=0.7)
def command_centre():
    if st.session_state.running:
        if not advance():
            st.session_state.running = False
    state = snapshot()
    services, incidents, exceptions = state['services'], state['incidents'], state['exceptions']
    healthy = sum(s['status']=='HEALTHY' for s in services)
    active = len([e for e in exceptions if e['status']=='ACTIVE'])
    cols = st.columns(6)
    for col, label, value in zip(cols,
        ['Active exceptions','Active incidents','Healthy services','Root causes identified','Auto-resolved','Mean resolution time'],
        [active,len(incidents),f'{healthy}/24','—','0','—']):
        col.metric(label,value)
    st.caption(f"System health: {'HEALTHY' if healthy==24 else 'DEGRADED'} · Human escalations: 0 · Graph connections run from upstream dependencies to downstream consumers.")
    a,b,c = st.columns([1,1,3])
    if a.button('Simulate Incident',type='primary',disabled=bool(incidents),use_container_width=True):
        start()
        st.session_state.running = True
        st.rerun(scope='fragment')
    if b.button('Pause' if st.session_state.running else 'Resume', disabled=not incidents or active>=23,use_container_width=True):
        st.session_state.running = not st.session_state.running
        st.rerun(scope='fragment')
    if c.button('Reset synthetic demo'):
        reset()
        st.session_state.running = False
        st.rerun(scope='fragment')
    if incidents:
        st.progress(active/23, text=f'Incident propagation · {active}/23 exceptions observed')
        st.warning('INC-2026-001 · DataHub Credential Failure · ACTIVE')
        if active == 23:
            st.info('Propagation complete: DataHub and 22 downstream services affected. Authentication Service remains healthy. Incident stays open; diagnosis and remediation require later phases.')
    else:
        st.success('All 24 services healthy. No active incidents.')
    st.subheader('Service dependency map')
    st.plotly_chart(figure(services),use_container_width=True,key='dependency-map')
    st.subheader('Service health')
    graph = build_graph(services)
    rows = [{'Service':s['name'],'Domain':s['domain'],'Status':s['status'],
             'Upstream':', '.join(graph.nodes[n]['name'] for n in graph.predecessors(s['id'])) or 'None',
             'Downstream':', '.join(graph.nodes[n]['name'] for n in graph.successors(s['id'])) or 'None',
             'Last successful run':s['last_success'], 'Recent change':s['recent_change'] or 'None',
             'Error':s['error_state'] or 'None',
             'Current incident': ', '.join(sorted({e['incident_id'] for e in exceptions if e['service_id']==s['id']})) or 'None'} for s in services]
    st.dataframe(rows,use_container_width=True,hide_index=True)
    st.subheader('Exception activity')
    if exceptions:
        names = {s['id']:s['name'] for s in services}
        st.dataframe([{'Time':e['timestamp'],'Exception':e['id'],'Service':names[e['service_id']],
                       'Error':e['error_code'],'Message':e['error_message'],'Severity':e['severity'],
                       'Business impact':e['business_impact']} for e in reversed(exceptions)],use_container_width=True,hide_index=True)
    else:
        st.caption('No exceptions detected.')

command_centre()
