import json
import sqlite3
from pathlib import Path
from core.models import Service, Status

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = ROOT / 'data' / 'operations.sqlite3'


def connect(path=DEFAULT_DB):
    db = sqlite3.connect(path, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    return db


def initialize(path=DEFAULT_DB):
    with connect(path) as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS services (
          id TEXT PRIMARY KEY, name TEXT NOT NULL, domain TEXT NOT NULL,
          dependencies TEXT NOT NULL, status TEXT NOT NULL, health_state TEXT NOT NULL,
          last_success TEXT, recent_change TEXT, error_state TEXT);
        CREATE TABLE IF NOT EXISTS incidents (
          id TEXT PRIMARY KEY, title TEXT NOT NULL, status TEXT NOT NULL,
          started_at TEXT NOT NULL, simulation_step INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS exceptions (
          id TEXT PRIMARY KEY, incident_id TEXT NOT NULL REFERENCES incidents(id),
          service_id TEXT NOT NULL REFERENCES services(id), timestamp TEXT NOT NULL,
          error_code TEXT NOT NULL, error_category TEXT NOT NULL,
          error_message TEXT NOT NULL, severity TEXT NOT NULL, business_impact TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'ACTIVE', UNIQUE(incident_id, service_id));
        ''')
        for service in json.loads((ROOT / 'data/seed_services.json').read_text()):
            model = Service(**service)
            db.execute('INSERT OR IGNORE INTO services VALUES (?,?,?,?,?,?,?,?,?)',
                       (model.id, model.name, model.domain,
                        json.dumps(model.dependencies), Status.HEALTHY.value, Status.HEALTHY.value,
                        '2026-11-17T08:55:00', None, None))


def snapshot(path=DEFAULT_DB):
    with connect(path) as db:
        return {table: [dict(row) for row in db.execute('SELECT * FROM ' + table)]
                for table in ('services', 'incidents', 'exceptions')}


def reset(path=DEFAULT_DB):
    with connect(path) as db:
        db.execute('DELETE FROM exceptions')
        db.execute('DELETE FROM incidents')
        db.execute("UPDATE services SET status='HEALTHY', health_state='HEALTHY', "
                   "last_success='2026-11-17T08:55:00', recent_change=NULL, error_state=NULL")
