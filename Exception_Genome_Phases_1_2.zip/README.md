# Exception Genome — Phases 1 and 2

Synthetic banking operations proof of concept. No real credentials, customer data, transactions or OCBC infrastructure.

## Run locally

Requires Python 3.10 or newer. From this directory:

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

The second command starts the application. SQLite initializes automatically at `data/operations.sqlite3`.

## Demo

1. Open the Command Centre: 24 healthy services, zero incidents and exceptions.
2. Click **Simulate Incident**. DataHub fails first. Every 0.7 seconds, another service produces a synthetic exception. Displayed timestamps advance by eight simulated seconds.
3. Use **Pause / Resume** to control propagation. Hover, zoom and pan the dependency graph to inspect services.
4. At completion there are exactly 23 exceptions: DataHub plus 22 downstream services. The independent Authentication Service remains healthy.
5. The incident stays ACTIVE. **Reset synthetic demo** clears the demo incident and restores service health; this is not a remediation.

SQLite persists across restarts. If a run is interrupted, click Resume. This local demo uses a shared database; use one presentation session at a time.

## Scope boundary

Implemented: modular structure, service models, SQLite, seed topology, NetworkX/Plotly dependency map, flagship incident propagation, exceptions, live service statuses and Command Centre.

Phases 3–8 are deliberately not implemented. No correlation, AI diagnosis, execution, verification, operational memory or review workflow is represented as functional. Unknown future metrics display a dash. The incident title comes from the selected synthetic scenario, not an inferred root cause. Later-phase database tables will be added alongside their implementation.

The fixed 2026-11-17 timestamps are simulated scenario time, not wall-clock monitoring.

## Verification

```powershell
python -m unittest discover -s tests -v
```
